/* daryaft aray pooya*/
char *get_dynamic_string()
{
    char *string = NULL;
    int i = 0, j = 2, character;
    string = (char *)malloc(sizeof(char));           /*takhsis hafeze pooya*/

    // error checking
    if (string == NULL)
    {
        printf("Error allocating memory\n");
        exit(EXIT_FAILURE);
    }

    while ((character = getc(stdin)) && character != '\n')
    {
        string[i] = character;
        string = realloc(string, j * sizeof(char));
        // error checking
        if (string == NULL)
        {
            printf("Error allocating memory\n");
            free(string);                           /*azad siza hafeze takhsis dade shode*/
            exit(EXIT_FAILURE);
        }

        i++;
        j++;
    }
    string[i] = '\0';
    return string;
}