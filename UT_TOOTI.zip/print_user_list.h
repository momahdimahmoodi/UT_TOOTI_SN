void print_user_list(struct User_List *list)
{
    struct User_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        print_user(current->user);
        current = current->next;
    }
}