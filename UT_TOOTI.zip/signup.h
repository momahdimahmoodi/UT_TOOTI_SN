            /*sign kardan karbar*/
void signup(struct User_List *list, char *name, char *password)
{
    new_user(list, name, password);
    printf("signup successful by name: %s password: %s.\n", name, password);
}