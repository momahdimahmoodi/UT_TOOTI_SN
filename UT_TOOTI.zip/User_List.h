struct User_List
{
    struct User_Node *dummy;
    int size;
};