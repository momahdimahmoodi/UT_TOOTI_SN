/*ejraye dastoor post */
void post(struct Post_List *post_list, struct User *user, char *content)
{
    int post_id = get_new_id();
    int likes = 0;
    new_post(post_list, user, post_id, likes, content);
    printf("post successful by user: %s post_id: %d\ncontent: %s.\n", user->name, post_id, content);
}