/*logout karbar*/
void logout(struct User **current_user)
{
    *current_user = NULL;
    printf("Logout successful\n");
}