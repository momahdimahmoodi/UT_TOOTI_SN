/* dadan etelaat baraye ezafe kardan an be linked lilst*/
void new_post(struct Post_List *list, struct User *author, int post_id, int likes, char *content) /**/
{
    struct Post_Node *new_node = (struct Post_Node *)malloc(sizeof(struct Post_Node));
    new_node->post = (struct Post *)malloc(sizeof(struct Post));
    post_constructor(new_node->post, author, post_id, likes, content);
    author->count_of_posts++;
    new_node->next = list->dummy;
    new_node->prev = list->dummy->prev;
    list->dummy->prev->next = new_node;
    list->dummy->prev = new_node;
    list->size++;
}