                    /*post ra hazf mikonim*/
void delete_post(struct Post_List *post_list, struct Post *post) 
{
    struct Post_Node *current = post_list->dummy->next;
    while (current != post_list->dummy)
    {
        if (current->post == post)
        {
            current->prev->next = current->next;
            current->next->prev = current->prev;
            free(current->post);   /*hazf node */
            free(current);
            post_list->size--;
            printf("Post deleted!\n");
            return;
        }
        current = current->next;
    }
}