void user_menu()
{
    printf("-------------- User Menu ---------------\n");
    printf("post <content>\n");
    printf("like <user_name> <post_id>\n");
    printf("delete <post_id>\n");
    printf("info\n");
    printf("find_user <user_name>\n");
    printf("logout\n");
}
