/* moghavem sazi barname*/
int command_identyfier(char *command)
{
    if (strcmp(command, "signup") == 0)
    {
        return 1;
    }
    else if (strcmp(command, "login") == 0)
    {
        return 2;
    }
    else if (strcmp(command, "post") == 0)
    {
        return 3;
    }
    else if (strcmp(command, "like") == 0)
    {
        return 4;
    }
    else if (strcmp(command, "logout") == 0)
    {
        return 5;
    }
    else if (strcmp(command, "delete") == 0)
    {
        return 6;
    }
    else if (strcmp(command, "info") == 0)
    {
        return 7;
    }
    else if (strcmp(command, "find_user") == 0)
    {
        return 8;
    }
    else if (strcmp(command, "exit") == 0)
    {
        return 9;
    }
    else
    {
        return 0;
    }
}