void user_constructor(struct User *user, char *name, char *password)
{
    user->name = name;
    user->password = password;
    user->count_of_posts = 0;
}