void login_menu()
{
    printf("-------------- Login Menu --------------\n");
    printf("login <username> <password>\n");
    printf("signup <username> <password>\n");
    printf("exit\n");
}