                            /*hazf post*/
void delete(struct Post_List *post_list, struct User *user, int post_id)
{
    struct Post *post = get_post(post_list, user, post_id);
    if (post == NULL)
    {
        printf("post not found.\n");
        return;
    }
    if (post->author != user)
    {
        printf("you can't delete this post.\n");
        return;
    }
    delete_post(post_list, post);
    printf("delete successful by user: %s post_id: %d.\n", user->name, post_id);
}