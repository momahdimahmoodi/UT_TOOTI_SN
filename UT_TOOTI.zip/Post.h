struct Post
{
    struct User *author;
    int post_id;
    int likes;
    char *content;
};