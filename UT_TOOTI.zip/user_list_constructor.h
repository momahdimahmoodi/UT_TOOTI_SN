
void user_list_constructor(struct User_List *list) /*az constructors baraye meghdar_dehi struct estefade mikonim  */
{
    list->dummy = (struct User_Node *)malloc(sizeof(struct User_Node));
    list->dummy->next = list->dummy;
    list->dummy->prev = list->dummy;
    list->size = 0;
}