                                    /*anjam amaliat asli barname*/
bool command_control(struct Post_List *post_list, struct User_List *user_list, struct User **current_user)
{
    if (*current_user == NULL)
    {
        login_menu();
    }
    else
    {
        user_menu();
    }

    printf("---------- Enter your command ----------\n");

    char *string = get_dynamic_string();
    char *command = strtok(string, " ");
    int command_id = command_identyfier(command);

    printf("----------------------------------------\n");

    if (*current_user == NULL && command_id != 1 && command_id != 2 && command_id != 9)
    {
        printf("You must login first\n");
        return true;
    }

    char *name;
    char *password;
    char *content;
    int post_id;

    switch (command_id)
    {
    case 1:
        name = strtok(NULL, " ");
        password = strtok(NULL, " ");
        signup(user_list, name, password);
        break;
    case 2:
        name = strtok(NULL, " ");
        password = strtok(NULL, " ");
        login(user_list, &(*current_user), name, password);
        break;
    case 3:
        content = strtok(NULL, "\n");
        post(post_list, (*current_user), content);
        break;
    case 4:
        name = strtok(NULL, " ");
        post_id = atoi(strtok(NULL, " "));
        like(post_list, user_list, name, post_id);
        break;
    case 5:
        logout(&(*current_user));
        break;
    case 6:
        post_id = atoi(strtok(NULL, " "));
        delete (post_list, (*current_user), post_id);
        break;
    case 7:
        info(post_list, user_list, (*current_user));
        break;
    case 8:
        name = strtok(NULL, " ");
        find_user(post_list, user_list, name);
        break;
    case 9:
        return false;
        break;
    default:
        printf("Invalid command\n");
        break;
    }
    return true;
}