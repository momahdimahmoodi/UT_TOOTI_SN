#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

//---------------- defines ----------------//

#define MAX_COMMAND_LENGTH 100
#define INPUT_SEPARATOR ' '

//---------------- Structs ---------------- //

struct User;
struct Post;
struct Post_Node;
struct User_Node;
struct User_List;
struct Post_List;

struct User
{
    char *name;
    char *password;
    int count_of_posts;
};

struct Post
{
    struct User *author;
    int post_id;
    int likes;
    char *content;
};

struct Post_Node
{
    struct Post *post;
    struct Post_Node *next;
    struct Post_Node *prev;
};

struct User_Node
{
    struct User *user;
    struct User_Node *next;
    struct User_Node *prev;
};

struct User_List
{
    struct User_Node *dummy;
    int size;
};

struct Post_List
{
    struct Post_Node *dummy;
    int size;
};

// --------------- Constructors --------------- //

void user_list_constructor(struct User_List *list) /*az constructors baraye meghdar_dehi struct estefade mikonim  */
{
    list->dummy = (struct User_Node *)malloc(sizeof(struct User_Node));
    list->dummy->next = list->dummy;
    list->dummy->prev = list->dummy;
    list->size = 0;
}

void post_list_constructor(struct Post_List *list)
{
    list->dummy = (struct Post_Node *)malloc(sizeof(struct Post_Node));
    list->dummy->next = list->dummy;
    list->dummy->prev = list->dummy;
    list->size = 0;
}

void user_constructor(struct User *user, char *name, char *password)
{
    user->name = name;
    user->password = password;
    user->count_of_posts = 0;
}

void post_constructor(struct Post *post, struct User *author, int post_id, int likes, char *content)
{
    post->author = author;
    post->post_id = post_id;
    post->likes = likes;
    post->content = content;
}

//---------------- Functions ---------------- //

/* dadan etelaat karbar baraye ezafe kardan an be linked lilst*/
void new_user(struct User_List *list, char *name, char *password)
{
    struct User_Node *new_node = (struct User_Node *)malloc(sizeof(struct User_Node));
    new_node->user = (struct User *)malloc(sizeof(struct User));
    user_constructor(new_node->user, name, password);
    new_node->next = list->dummy;
    new_node->prev = list->dummy->prev;
    list->dummy->prev->next = new_node;
    list->dummy->prev = new_node;
    list->size++;
}
/* dadan etelaat baraye ezafe kardan an be linked lilst*/
void new_post(struct Post_List *list, struct User *author, int post_id, int likes, char *content)
{
    struct Post_Node *new_node = (struct Post_Node *)malloc(sizeof(struct Post_Node));
    new_node->post = (struct Post *)malloc(sizeof(struct Post));
    post_constructor(new_node->post, author, post_id, likes, content);
    author->count_of_posts++;
    new_node->next = list->dummy;
    new_node->prev = list->dummy->prev;
    list->dummy->prev->next = new_node;
    list->dummy->prev = new_node;
    list->size++;
}
/*search kardan dar linked_list va bargardandan etelaat  post moshakhas */
struct Post *get_post(struct Post_List *list, struct User *author, int post_id)
{
    struct Post_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (current->post->author == author && current->post->post_id == post_id)
        {
            return current->post;
        }
        current = current->next;
    }
    return NULL;
}
/*search kardan dar linked_list va bargardandan etelaat karbar moshakhas */
struct User *get_user(struct User_List *list, char *name)
{
    struct User_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (strcmp(current->user->name, name) == 0)
        {
            return current->user;
        }
        current = current->next;
    }
    return NULL;
}
/*post ra hazf mikonim*/
void delete_post(struct Post_List *post_list, struct Post *post)
{
    struct Post_Node *current = post_list->dummy->next;
    while (current != post_list->dummy)
    {
        if (current->post == post)
        {
            current->prev->next = current->next;
            current->next->prev = current->prev;
            free(current->post); /*hazf node */
            free(current);
            post_list->size--;
            printf("Post deleted!\n");
            return;
        }
        current = current->next;
    }
}

void like_post(struct Post *post)
{
    post->likes++;
}

void print_user_posts(struct Post_List *list, struct User *user)
{
    struct Post_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (current->post->author == user)
        {
            printf("----------------------------------------\n");
            printf("Post ID: %d\n", current->post->post_id);
            printf("Likes: %d\n", current->post->likes);
            printf("Content: %s\n", current->post->content);
        }
        current = current->next;
    }
}
/*name va password karbar ra print mikonim*/
void print_user(struct User *user)
{
    printf("User Name: %s\n", user->name);
    printf("Password: %s\n", user->password);
}
/* moghavem sazi barname*/
int command_identyfier(char *command)
{
    if (strcmp(command, "signup") == 0)
    {
        return 1;
    }
    else if (strcmp(command, "login") == 0)
    {
        return 2;
    }
    else if (strcmp(command, "post") == 0)
    {
        return 3;
    }
    else if (strcmp(command, "like") == 0)
    {
        return 4;
    }
    else if (strcmp(command, "logout") == 0)
    {
        return 5;
    }
    else if (strcmp(command, "delete") == 0)
    {
        return 6;
    }
    else if (strcmp(command, "info") == 0)
    {
        return 7;
    }
    else if (strcmp(command, "find_user") == 0)
    {
        return 8;
    }
    else if (strcmp(command, "exit") == 0)
    {
        return 9;
    }
    else
    {
        return 0;
    }
}
/* daryaft aray pooya*/
char *get_dynamic_string()
{
    char *string = NULL;
    int i = 0, j = 2, character;
    string = (char *)malloc(sizeof(char)); /*takhsis hafeze pooya*/

    // error checking
    if (string == NULL)
    {
        printf("Error allocating memory\n");
        exit(EXIT_FAILURE);
    }

    while ((character = getc(stdin)) && character != '\n')
    {
        string[i] = character;
        string = realloc(string, j * sizeof(char));
        // error checking
        if (string == NULL)
        {
            printf("Error allocating memory\n");
            free(string); /*azad siza hafeze takhsis dade shode*/
            exit(EXIT_FAILURE);
        }

        i++;
        j++;
    }
    string[i] = '\0';
    return string;
}

int get_new_id()
{
    static int id = 0;
    return id++;
}
/*sign kardan karbar*/
void signup(struct User_List *list, char *name, char *password)
{
    new_user(list, name, password);
    printf("signup successful by name: %s password: %s.\n", name, password);
}
/*ejraye dastoor post */
void post(struct Post_List *post_list, struct User *user, char *content)
{
    int post_id = get_new_id();
    int likes = 0;
    new_post(post_list, user, post_id, likes, content);
    printf("post successful by user: %s post_id: %d\ncontent: %s.\n", user->name, post_id, content);
}
/*post ra like mikonim*/
void like(struct Post_List *post_list, struct User_List *user_list, char *name, int post_id)
{
    struct User *user = get_user(user_list, name);
    if (user == NULL)
    {
        printf("user not found.\n");
        return;
    }

    struct Post *post = get_post(post_list, user, post_id);
    if (post == NULL)
    {
        printf("post not found.\n");
        return;
    }

    like_post(post);
    printf("like successful by user: %s post_id: %d.\n", user->name, post_id);
}
/*hazf post*/
void delete(struct Post_List *post_list, struct User *user, int post_id)
{
    struct Post *post = get_post(post_list, user, post_id);
    if (post == NULL)
    {
        printf("post not found.\n");
        return;
    }
    if (post->author != user)
    {
        printf("you can't delete this post.\n");
        return;
    }
    delete_post(post_list, post);
    printf("delete successful by user: %s post_id: %d.\n", user->name, post_id);
}

void info(struct Post_List *post_list, struct User_List *user_list, struct User *user)
{
    print_user(user);
    print_user_posts(post_list, user);
}

void find_user(struct Post_List *post_list, struct User_List *user_list, char *user_name)
{
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        if (strcmp(current->user->name, user_name) == 0)
        {
            printf("User Name: %s\n", current->user->name);
            print_user_posts(post_list, current->user);
            return;
        }
        current = current->next;
    }
    printf("User not found\n");
}

void login(struct User_List *list, struct User **current_user, char *name, char *password)
{
    struct User *user = get_user(list, name);
    if (user == NULL)
    {
        printf("User not found\n");
        return;
    }
    if (strcmp(user->password, password) == 0)
    {
        *current_user = user;
        printf("%s logged in successfully \n", (*current_user)->name);
    }
    else
    {
        printf("Wrong password\n");
    }
}

void logout(struct User **current_user)
{
    *current_user = NULL;
    printf("Logout successful\n");
}

void login_menu()
{
    printf("-------------- Login Menu --------------\n");
    printf("login <username> <password>\n");
    printf("signup <username> <password>\n");
    printf("exit\n");
}

void user_menu()
{
    printf("-------------- User Menu ---------------\n");
    printf("post <content>\n");
    printf("like <user_name> <post_id>\n");
    printf("delete <post_id>\n");
    printf("info\n");
    printf("find_user <user_name>\n");
    printf("logout\n");
}

void print_user_list(struct User_List *list)
{
    struct User_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        print_user(current->user);
        current = current->next;
    }
}
/*anjam amaliat asli barname*/
bool command_control(struct Post_List *post_list, struct User_List *user_list, struct User **current_user)
{
    if (*current_user == NULL)
    {
        login_menu();
    }
    else
    {
        user_menu();
    }

    printf("---------- Enter your command ----------\n");

    char *string = get_dynamic_string();
    char *command = strtok(string, " ");
    int command_id = command_identyfier(command);

    printf("----------------------------------------\n");

    if (*current_user == NULL && command_id != 1 && command_id != 2 && command_id != 9)
    {
        printf("You must login first\n");
        return true;
    }

    char *name;
    char *password;
    char *content;
    int post_id;

    switch (command_id)
    {
    case 1:
        name = strtok(NULL, " ");
        password = strtok(NULL, " ");
        signup(user_list, name, password);
        break;
    case 2:
        name = strtok(NULL, " ");
        password = strtok(NULL, " ");
        login(user_list, &(*current_user), name, password);
        break;
    case 3:
        content = strtok(NULL, "\n");
        post(post_list, (*current_user), content);
        break;
    case 4:
        name = strtok(NULL, " ");
        post_id = atoi(strtok(NULL, " "));
        like(post_list, user_list, name, post_id);
        break;
    case 5:
        logout(&(*current_user));
        break;
    case 6:
        post_id = atoi(strtok(NULL, " "));
        delete (post_list, (*current_user), post_id);
        break;
    case 7:
        info(post_list, user_list, (*current_user));
        break;
    case 8:
        name = strtok(NULL, " ");
        find_user(post_list, user_list, name);
        break;
    case 9:
        return false;
        break;
    default:
        printf("Invalid command\n");
        break;
    }
    return true;
}
/*neveshtan etelaat karbar ha dar file*/
void write_users_info_to_file(struct User_List *user_list)
{
    FILE *file = fopen("./accounts.txt", "w");
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        fprintf(file, "%s %s %d\n", current->user->name, current->user->password, current->user->count_of_posts);
        current = current->next;
    }
}
/*neveshtan etelaat post ha dar file*/
void write_posts_info_to_file(struct User_List *user_list, struct Post_List *post_list)
{
    FILE *file = fopen("./posts.txt", "w");
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        struct Post_Node *current_post = post_list->dummy->next;
        while (current_post != post_list->dummy)
        {
            if (current_post->post->author == current->user)
            {
                fprintf(file, "%s %s %d\n", current_post->post->content, current_post->post->author->name, current_post->post->likes);
            }
            current_post = current_post->next;
        }
        current = current->next;
    }
}

int main()
{
    struct User_List user_list;
    struct Post_List post_list;

    user_list_constructor(&user_list);
    post_list_constructor(&post_list);

    struct User *current_user = NULL;

    while (true)
    {
        if (command_control(&post_list, &user_list, &current_user) == false)
        {
            break;
        }
    }

    write_users_info_to_file(&user_list);
    write_posts_info_to_file(&user_list, &post_list);

    return 0;
}
