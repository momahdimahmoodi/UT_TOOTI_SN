void print_user_posts(struct Post_List *list, struct User *user) /* print post ha*/
{
    struct Post_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (current->post->author == user)
        {
            printf("----------------------------------------\n");
            printf("Post ID: %d\n", current->post->post_id);
            printf("Likes: %d\n", current->post->likes);
            printf("Content: %s\n", current->post->content);
        }
        current = current->next;
    }
}