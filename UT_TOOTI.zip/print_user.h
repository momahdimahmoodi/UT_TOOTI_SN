void print_user(struct User *user) /*name va password karbar ra print mikonim*/
{
    printf("User Name: %s\n", user->name);
    printf("Password: %s\n", user->password);
}