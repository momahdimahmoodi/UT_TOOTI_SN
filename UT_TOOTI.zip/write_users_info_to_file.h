/*neveshtan etelaat karbar ha dar file*/
void write_users_info_to_file(struct User_List *user_list)
{
    FILE *file = fopen("./accounts.txt", "w");
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        fprintf(file, "%s %s %d\n", current->user->name, current->user->password, current->user->count_of_posts);
        current = current->next;
    }
}