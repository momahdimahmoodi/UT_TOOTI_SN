/* dadan etelaat karbar baraye ezafe kardan an be linked lilst*/
void new_user(struct User_List *list, char *name, char *password) /*karbar jadid misazim*/
{
    struct User_Node *new_node = (struct User_Node *)malloc(sizeof(struct User_Node));
    new_node->user = (struct User *)malloc(sizeof(struct User));
    user_constructor(new_node->user, name, password);
    new_node->next = list->dummy;
    new_node->prev = list->dummy->prev;
    list->dummy->prev->next = new_node;
    list->dummy->prev = new_node;
    list->size++;
}