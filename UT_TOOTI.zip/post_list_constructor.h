
void post_list_constructor(struct Post_List *list)
{
    list->dummy = (struct Post_Node *)malloc(sizeof(struct Post_Node));
    list->dummy->next = list->dummy;
    list->dummy->prev = list->dummy;
    list->size = 0;
}