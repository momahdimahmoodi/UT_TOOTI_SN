int get_new_id()
{
    static int id = 0;
    return id++;
}