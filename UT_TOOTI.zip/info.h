/* darryaft etelaat karbar */
void info(struct Post_List *post_list, struct User_List *user_list, struct User *user)
{
    print_user(user);
    print_user_posts(post_list, user);
}