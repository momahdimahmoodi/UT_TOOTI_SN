struct Post_List
{
    struct Post_Node *dummy;
    int size;
};