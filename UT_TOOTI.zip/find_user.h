/*peida kardan karbar va didan etelaat karbar*/
void find_user(struct Post_List *post_list, struct User_List *user_list, char *user_name)
{
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        if (strcmp(current->user->name, user_name) == 0)
        {
            printf("User Name: %s\n", current->user->name);
            print_user_posts(post_list, current->user);
            return;
        }
        current = current->next;
    }
    printf("User not found\n");
}