/*search kardan dar linked_list va bargardandan etelaat  post moshakhas */
struct Post *get_post(struct Post_List *list, struct User *author, int post_id)
{
    struct Post_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (current->post->author == author && current->post->post_id == post_id)
        {
            return current->post;
        }
        current = current->next;
    }
    return NULL;
}