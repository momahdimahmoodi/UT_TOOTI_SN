                            /*post ra like mikonim*/
void like(struct Post_List *post_list, struct User_List *user_list, char *name, int post_id)
{
    struct User *user = get_user(user_list, name);
    if (user == NULL)
    {
        printf("user not found.\n");
        return;
    }

    struct Post *post = get_post(post_list, user, post_id);
    if (post == NULL)
    {
        printf("post not found.\n");
        return;
    }

    like_post(post);
    printf("like successful by user: %s post_id: %d.\n", user->name, post_id);
}