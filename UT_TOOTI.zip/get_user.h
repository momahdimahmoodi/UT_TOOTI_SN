/*search kardan dar linked_list va bargardandan etelaat karbar moshakhas */
struct User *get_user(struct User_List *list, char *name)
{
    struct User_Node *current = list->dummy->next;
    while (current != list->dummy)
    {
        if (strcmp(current->user->name, name) == 0)
        {
            return current->user;
        }
        current = current->next;
    }
    return NULL;
}
