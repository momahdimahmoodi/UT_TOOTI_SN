void post_constructor(struct Post *post, struct User *author, int post_id, int likes, char *content)
{
    post->author = author;
    post->post_id = post_id;
    post->likes = likes;
    post->content = content;
}