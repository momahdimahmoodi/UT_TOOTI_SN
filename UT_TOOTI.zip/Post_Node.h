struct Post_Node
{
    struct Post *post;
    struct Post_Node *next;
    struct Post_Node *prev;
};