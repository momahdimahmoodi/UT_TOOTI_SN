                                /*login karbar*/
void login(struct User_List *list, struct User **current_user, char *name, char *password)
{
    struct User *user = get_user(list, name);
    if (user == NULL)
    {
        printf("User not found\n");
        return;
    }
    if (strcmp(user->password, password) == 0)
    {
        *current_user = user;
        printf("%s logged in successfully \n", (*current_user)->name);
    }
    else
    {
        printf("Wrong password\n");
    }
}
