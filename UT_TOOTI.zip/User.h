struct User
{
    char *name;
    char *password;
    int count_of_posts;
};