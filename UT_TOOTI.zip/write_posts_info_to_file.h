/*neveshtan etelaat post ha dar file*/
void write_posts_info_to_file(struct User_List *user_list, struct Post_List *post_list)
{
    FILE *file = fopen("./posts.txt", "w");
    struct User_Node *current = user_list->dummy->next;
    while (current != user_list->dummy)
    {
        struct Post_Node *current_post = post_list->dummy->next;
        while (current_post != post_list->dummy)
        {
            if (current_post->post->author == current->user)
            {
                fprintf(file, "%s %s %d\n", current_post->post->content, current_post->post->author->name, current_post->post->likes);
            }
            current_post = current_post->next;
        }
        current = current->next;
    }
}