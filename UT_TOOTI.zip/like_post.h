void like_post(struct Post *post)
{
    post->likes++;
}