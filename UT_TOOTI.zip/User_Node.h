struct User_Node
{
    struct User *user;
    struct User_Node *next;
    struct User_Node *prev;
};